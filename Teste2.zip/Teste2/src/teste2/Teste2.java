package teste2;

import javax.swing.JFrame;


public class Teste2 {

        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      
        // TODO code application logic here
    }
    
}
