package SAAT;
import java.util.List;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import logica.Datasus;
import java.lang.String;

public class Modelo extends AbstractTableModel{
    
    private final Datasus datasus1;
    private final List <String> municipio;
    private final String[] colunas = {"municipio","total","noveseis","novesete","noveoito","novenove","doiszero","doisum","doisdois","doistres","doisquatro","doiscinco","doisseis","doissete","doisoito","doisnove","doisdez","doisonze","doisdoze","doistreze","doiscatorze"};
    private static final int MUNICIPIO = 0;
    private static final int TOTAL = 1; 
    private static final int NOVESEIS= 2;
    private static final int NOVESETE= 3;
    private static final int NOVEOITO= 4;
    private static final int NOVENOVE = 5;
    private static final int DOISZERO = 6;
    private static final int DOISUM = 7;
    private static final int DOISDOIS = 8;
    private static final int DOISTRES = 9;
    private static final int DOISQUATRO = 10;
    private static final int DOISCINCO = 11;
    private static final int DOISSEIS = 12;
    private static final int DOISSETE = 13;
    private static final int DOISOITO = 14;
    private static final int DOISNOVE = 15; 
    private static final int DOISDEZ = 16;
    private static final int DOISONZE = 17;
    private static final int DOISDOZE = 18;
    private static final int DOISTREZE = 19;
    private static final int DOISCATORZE = 20;
    
    public Modelo (Datasus datasus2){
        datasus1 = datasus2;     
        municipio = new ArrayList();
    }
    
    //Precisam ser dadas implementações dos 3 métodos a seguir, para poder ser extendida de AbstractTableModel
    
    @Override
    public int getRowCount() {
        return municipio.size();
    }

    @Override
    public int getColumnCount() {
        return colunas.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        
        String municipio2 = municipio.get(rowIndex);
        switch(columnIndex){
            
            case TOTAL:
                return datasus1.getTotal();
            case NOVESEIS:
                return datasus1.getNoveseis();
            case NOVESETE:
                return datasus1.getNovesete();
            case NOVEOITO:
                return datasus1.getNoveoito();
            case NOVENOVE:
                return datasus1.getNovenove();
            case DOISZERO:
                return datasus1.getDoiszero();
            case DOISUM:
                return datasus1.getDoisum();
            case DOISDOIS:
                return datasus1.getDoisdois();
            case DOISTRES:
                return datasus1.getDoistres();
            case DOISQUATRO:
                return datasus1.getDoisquatro();
            case DOISCINCO:
                return datasus1.getDoiscinco();
            case DOISSEIS:
                return datasus1.getDoisseis();
            case DOISSETE:
                return datasus1.getDoissete();
            case DOISOITO:
                return datasus1.getDoisoito();
            case DOISNOVE:
                return datasus1.getDoisnove();
            case DOISDEZ:
                return datasus1.getDoisdez();
            case DOISONZE:
                return datasus1.getDoisonze();
            case DOISDOZE:
                return datasus1.getDoisdoze();
            case DOISTREZE:
                return datasus1.getDoistreze();
            case DOISCATORZE:
                return datasus1.getDoiscatorze();
                            
        }
        
        return municipio2;
        
    }
    
    
}
