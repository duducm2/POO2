package logica;

import java.io.Serializable;
import java.util.Set;

public class Datasus implements Serializable{
    private String municipio;
    private String total;
    private String noveseis;
    private String novesete;
    private String noveoito;
    private String novenove;
    private String doiszero;
    private String doisum;
    private String doisdois;
    private String doistres;
    private String doisquatro;
    private String doiscinco;
    private String doisseis;
    private String doissete;
    private String doisoito;
    private String doisnove;
    private String doisdez;
    private String doisonze;
    private String doisdoze;
    private String doistreze;
    private String doiscatorze;

public void setMunicipio(String municipio){
  this.municipio = municipio;
}
public String getMunicipio(){
    return municipio;
}

public void setTotal(String total){
  this.total = total;
}
public String getTotal(){
    return total;
}

public void setNoveseis(String noveseis){
  this.noveseis = noveseis;
}
public String getNoveseis(){
  return noveseis;
}


public void setNovesete(String novesete){
  this.novesete = novesete;
}
public String getNovesete(){
  return novesete;
}


public void setNoveoito(String noveoito){
  this.noveoito = noveoito;
}
public String getNoveoito(){
  return noveoito;
}


public void setNovenove(String novenove){
  this.novenove = novenove;
}
public String getNovenove(){
  return novenove;
}


public void setDoiszero(String doiszero){
  this.doiszero = doiszero;
}
public String getDoiszero(){
  return doiszero;
}


public void setDoisum(String doisum){
  this.doisum = doisum;
}
public String getDoisum(){
  return doisum;
}


public void setDoisdois(String doisdois){
  this.doisdois = doisdois;
}
public String getDoisdois(){
  return doisdois;
}


public void setDoistres(String doistres){
  this.doistres = doistres;
}
public String getDoistres(){
  return doistres;
}


public void setDoisquatro(String doisquatro){
  this.doisquatro = doisquatro;
}
public String getDoisquatro(){
  return doisquatro;
}


public void setDoiscinco(String doiscinco){
  this.doiscinco = doiscinco;
}
public String getDoiscinco(){
  return doiscinco;
}


public void setDoisseis(String doisseis){
  this.doisseis = doisseis;
}
public String getDoisseis(){
  return doisseis;
}


public void setDoissete(String doissete){
  this.doissete = doissete;
}
public String getDoissete(){
  return doissete;
}


public void setDoisoito(String doisoito){
  this.doisoito = doisoito;
}
public String getDoisoito(){
  return doisoito;
}


public void setDoisnove(String doisnove){
  this.doisnove = doisnove;
}
public String getDoisnove(){
  return doisnove;
}


public void setDoisdez(String doisdez){
  this.doisdez = doisdez;
 }
public String getDoisdez(){
  return doisdez;
}


public void setDoisonze(String doisonze){
  this.doisonze = doisonze;
}
public String getDoisonze(){
  return doisonze;
}


public void setDoisdoze(String doisdoze){
  this.doisdoze = doisdoze;
}
public String getDoisdoze(){
  return doisdoze;
}


public void setDoistreze(String doistreze){
  this.doistreze = doistreze;
}
public String getDoistreze(){
  return doistreze;
}


public void setDoiscatorze(String doiscatorze){
  this.doiscatorze = doiscatorze;
}
public String getDoiscatorze(){
  return doiscatorze;
 }


}

